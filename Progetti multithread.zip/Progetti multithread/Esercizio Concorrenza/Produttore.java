public class Produttore {
    public int cont;        //dato condiviso

    public Produttore(int cont){
        this.cont = cont;
    }
    public void incrementa(int n, String nomeThread){
        this.cont = this.cont + n;
        System.out.println("Il thread " + nomeThread + " incrementa il contatore di "+ n);
    }
    public int getValue(){
        if(cont == 0){
            return 0; 
        }
        else if(cont > 0){
            return 1;
        }
    }
}
