public class Main{
    public static void main(String[] args) {
        Produttore C = new Produttore(0);

        Consumatore t1= new Consumatore("t1", C);
        Consumatore t2= new Consumatore("t2", C);
        Consumatore t3= new Consumatore("t3", C);
        System.out.println("Partenza del processo principale");
        t1.start();
        t2.start();
        t3.start();
        try {
            t1.join();
            t2.join();
            t3.join();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}