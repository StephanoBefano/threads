public class Consumatore extends Thread{
    public Produttore cont;      //oggetto condiviso tra i thread
    
    public Consumatore(String nome, Produttore c){
        super(nome);
        this.cont=c;
    }
    
    public void run(){
        System.out.println("Partenza del thread "+ getName());
        int n = (int)(Math.random()*10);
        this.cont.incrementa(n, getName());
        //il thread incrementa di un valore casuale cont
        System.out.println("Fine del thread "+ getName());
    }

    public int Get(){
        
}

