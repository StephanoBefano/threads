public class Concorrenza extends Thread{
    public Contatore cont;
    public int priorita;
    public Utente persona;

    public Concorrenza (String nome, Contatore cont, int priorita, Utente persona){
        super(nome);
        this.cont= cont;
        this.priorita= priorita; 
        this.persona=persona;
    }
    public void run(){
        System.out.println("Partenza del thread "+ getName());
        this.cont.incrementa(priorita, getName(), persona);
    }

}