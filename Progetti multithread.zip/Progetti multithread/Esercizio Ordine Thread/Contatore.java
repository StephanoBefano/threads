import java.util.ArrayList;

public class Contatore {
    public ArrayList<Utente> listaUtenti = new ArrayList<>();
    public int cont;

    public Contatore(ArrayList<Utente> listaUtenti,int cont){
        this.listaUtenti = listaUtenti;
        this.cont = cont;
    }
    public void incrementa(int priorita, String nome, Utente persona){
        synchronized (this){
            while(this.cont != priorita){
                try {
                    System.out.println("Il thread "+ nome + " viene sospeso");
                    wait();    
                    System.out.println("Il thread " + nome + " riparte");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
                this.cont++;
                listaUtenti.add(persona);
                System.out.println("Il thread "+ nome + " incrementa cont");
                notifyAll();
                //notifyAll toglie tutti i thread dalla lista di wait e quindi possono riprendere l'esecuzione
                //notifyAll non rilascia il lock
                //i thread sospesi possono tornare in esecuzione solo dopo aver riacquisito il lock
        }
    }
}