public class Utente {
    public String nome;
    public String cognome;
    public String codiceFiscale;

    public Utente(String nome, String cognome, String codiceFiscale){
        this.nome = nome;
        this.cognome = cognome;
        this.codiceFiscale = codiceFiscale;
    }
}
