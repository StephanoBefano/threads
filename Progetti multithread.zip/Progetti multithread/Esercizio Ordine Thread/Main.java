import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Utente p1 = new Utente("pippo", "rossi", "JSAKFOSAHF");
        Utente p2 = new Utente("gigi", "rossi", "JSAKFOSAHF");
        Utente p3 = new Utente("piero", "rossi", "JSAKFOSAHF");
        Utente p4 = new Utente("gino", "rossi", "JSAKFOSAHF");

        Contatore cont = new Contatore(new ArrayList<>(), 0);
        Concorrenza t1 = new Concorrenza("t1", cont, 0, p1);
        Concorrenza t2 = new Concorrenza("t2", cont, 3, p2);
        Concorrenza t3 = new Concorrenza("t3", cont, 2, p3);
        Concorrenza t4 = new Concorrenza("t4", cont, 1, p4);
        System.out.println("Inizio del processo principale");
        t1.start();
        t2.start();
        t3.start();
        t4.start();
        //lancio il thread
        try {
            t1.join();
            t2.join();
            t3.join();
            t4.join();
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Valore finale di cont "+ cont.cont);
        System.out.println("Fine del processo principale");
        for (Utente pUtente : cont.listaUtenti) {
            System.out.println(pUtente.nome);
        }
        
    }

}
