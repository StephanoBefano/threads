public class Main {
    public static void main(String[] args) {
        Contatore cont = new Contatore(1);
        Concorrenza t1 = new Concorrenza("t1", cont, 4);
        Concorrenza t2 = new Concorrenza("t2", cont, 3);
        Concorrenza t3 = new Concorrenza("t3", cont, 2);
        Concorrenza t4 = new Concorrenza("t4", cont, 1);
        System.out.println("Inizio del processo principale");
        t1.start();
        t2.start();
        t3.start();
        t4.start();
        //lancio il thread
        try {
            t1.join();
            t2.join();
            t3.join();
            t4.join();
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Valore finale di cont "+ cont.cont);
        System.out.println("Fine del processo principale");
    }
}
