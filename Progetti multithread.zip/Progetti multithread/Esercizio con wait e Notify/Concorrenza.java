public class Concorrenza extends Thread{
    public Contatore cont;      //Struttura dati condivisa tra i thread

    public int priorita;
    //Ogni thread ha una diversa priorità perché voglio che i thread accedano
    //al contatore nell'ordine di priorità
    public Concorrenza (String nome, Contatore cont, int priorita){
        super(nome);
        this.cont= cont;
        this.priorita= priorita; 
    }
    public void run(){
        System.out.println("Partenza del thread "+ getName());
        //il thread incrementa il contatore quando ne ha diritto
        this.cont.incrementa(priorita, getName());
    }
}
