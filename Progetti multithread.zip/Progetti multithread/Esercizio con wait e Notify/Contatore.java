public class Contatore {
    public int cont;                    //contatore

    public Contatore(int cont){         //inizializza il contatore
        this.cont=cont;
    }
    //il metodo incrementa il contatore
    public void incrementa(int priorita, String nome){
        synchronized (this){
            while(this.cont != priorita){
                //se la prioritò del thread non è uguale al valore di cont allora
                //chiamo la wait
                //la wait mette il thread nella lista di wiat cioè mette in attesa il thread
                //e viene rilasciato il lock.
                try {
                    System.out.println("Il thread "+ nome + " viene sospeso");
                    wait();    
                    System.out.println("Il thread " + nome + " riparte");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
                //Il thread può incrementare il contatore perché la priorità è uguale a cont
                this.cont++;
                System.out.println("Il thread "+ nome + " incrementa cont");
                notifyAll();
                //notifyAll toglie tutti i thread dalla lista di wait e quindi possono riprendere l'esecuzione
                //notifyAll non rilascia il lock
                //i thread sospesi possono tornare in esecuzione solo dopo aver riacquisito il lock
                //wait, notify e notifyAll vanno inseriti in un blocco synchronized o in un metodo synchronized
                System.out.println("Fine del thread "+ nome);
                System.out.println();
                //notify toglie un solo thread dalla lista di wait che non rilascia il lock.
            
        }
    }
}

