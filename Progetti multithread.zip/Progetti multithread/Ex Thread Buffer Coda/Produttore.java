public class Produttore extends Thread{
    public Buffer b;

    public Produttore(String nome, Buffer b){
        super(nome);
        this.b=b;
        //tutti i thread hanno accesso allo stesso buffer condiviso
    }
    public void run(){
        System.out.println("Partenza del thread " + getName());
        //il produttore aggiunge un dato al buffer
        int n = (int)(Math.random()*10);        //genera un valore casuale tra 0 e 9 intero
        System.out.println("Fine del thread " + getName());
        this.b.aggiungi(n, getName());
    }
}

