import java.util.ArrayList;

public class Buffer {
    public ArrayList<Integer> coda;
    public int n;               //valore presente nel buffer

    public Buffer(){
        this.coda=new ArrayList<>(100);
    }

    //il metodo aggiunge un dato al buffer
    public void aggiungi(int n, String nome){
        synchronized (this){
            while(coda.size() <100){
                //se il buffer è pieno
                System.out.println("Il thread " + nome + " viene sospeso");
                try {
                    wait();
                    //il thread viene messo in attesa
                } catch (Exception e) {
                    e.printStackTrace();
                }
                System.out.println("Il thread " + nome + " riprende l'esecuzione");
                
            }
            //il buffer è vuoto
            this.n = n;       //aggiungo il dato al buffer
            while(coda.size()<10){
                coda.add(n);
                System.out.println("Il thread " + nome + " ha aggiunto al buffer " + this.n);
                
            }
            for (Integer element : coda) {
                System.out.println(element);
            }
            
            notifyAll();
        }
        
    }
    // il metodo toglie un dato dal buffer
    public int togli(String nome){
        synchronized (this){
            while(coda.isEmpty()){
                //se il buffer è vuoto
                System.out.println("Il thread " + nome + " viene sospeso");
                try {
                    wait();                 //sospendo il thread
                } catch (Exception e) {
                    e.printStackTrace();
                }
                System.out.println("Il thread " + nome + " riprende l'esecuzione");
                
            }
            //il buffer non è vuoto
            System.out.println("Il thread " + nome + " ha tolto dal buffer " + this.n);
            notifyAll();
            return this.n;
        }
    }
}