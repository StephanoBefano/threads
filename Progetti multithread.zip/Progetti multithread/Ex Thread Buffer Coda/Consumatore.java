public class Consumatore extends Thread{
    public Buffer b;
    //buffer condiviso
    public Consumatore(String nome, Buffer b){
        super(nome);
        this.b=b;
    }
    public void run(){
        System.out.println("Partenza del thread " + getName());
        //il consumatore toglie un dato dal buffer
        this.b.togli(getName());
        //il dato è restituito per ulteriori elaborazioni
        System.out.println("Fine del thread " + getName());
    }
}

