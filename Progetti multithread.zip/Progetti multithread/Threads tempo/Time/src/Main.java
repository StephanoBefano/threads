public class Main {
    public static void main(String[] args) throws Exception {
        System.out.println("Partenza del processo");

        long start = System.currentTimeMillis();

        Concorrenza[] T = new Concorrenza[100];

        for (int i = 0; i < T.length; i++) {
            T[i] = new Concorrenza("T" + i, i);
        }

        for (int i = 0; i < T.length; i++) {
            T[i].start();
        }

        for (int i = 0; i < T.length; i++) {
            T[i].join();
        }

        long stop = System.currentTimeMillis();
        double tempo = (double)(stop-start)/1000;
        System.out.println("Tempo del main di " + tempo + " secondi");

    }
}
