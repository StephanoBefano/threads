public class Concorrenza extends Thread{
    
    private String name;
    private double time;
    

    Concorrenza(String name, double time){
        this.name=name;
        this.time=time;
    }

    @Override
    public void run() {
        System.out.println("Partenza del Thread: " + name);
        long start = System.currentTimeMillis();
        try {
            int rand = (int)(Math.random()*10);
            Thread.sleep(rand);
        } catch (Exception e) {

        }
        long stop = System.currentTimeMillis();
        double time = (double)(stop-start)/1000;
        System.out.println("Tempo del thread " + name + " di " + time + " secondi");
    }
}