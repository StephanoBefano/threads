public class Main{
    public static void main(String[] args) {
        //creo il buffer
        Buffer b= new Buffer();
        //passo il buffer ai thread
        Produttore p1 = new Produttore("p1", b);
        Consumatore c1 = new Consumatore("c1", b);
        Produttore p2 = new Produttore("p2", b);
        Consumatore c2 = new Consumatore("c2", b);  

        System.out.println("Partenza del processo principale");

        p1.start();
        p2.start();
        c1.start();
        c2.start();

        try {
            p1.join();
            p2.join();
            c1.join();
            c2.join();
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Fine del processo principale");

    }
}