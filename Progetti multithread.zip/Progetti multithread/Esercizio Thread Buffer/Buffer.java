public class Buffer {
    public boolean pieno;       //indica se è presente un valore nel buffer
    public int n;               //valore presente nel buffer

    public Buffer(){
        this.pieno = false;      //all'inizio il buffer è vuoto
    }

    //il metodo aggiunge un dato al buffer
    public void aggiungi(int n, String nome){
        synchronized (this){
            while(this.pieno == true){
                //se il buffer è pieno
                System.out.println("Il thread " + nome + " viene sospeso");
                try {
                    wait();
                    //il thread viene messo in attesa
                } catch (Exception e) {
                    e.printStackTrace();
                }
                System.out.println("Il thread " + nome + " riprende l'esecuzione");
                
            }
            //il buffer è vuoto
            this.n = n;       //aggiungo il dato al buffer
            this.pieno = true;
            System.out.println("Il thread " + nome + " ha aggiunto al buffer " + this.n);
            notifyAll();
        }
        
    }
    // il metodo toglie un dato dal buffer
    public int togli(String nome){
        synchronized (this){
            while(this.pieno == false){
                //se il buffer è vuoto
                System.out.println("Il thread " + nome + " viene sospeso");
                try {
                    wait();                 //sospendo il thread
                } catch (Exception e) {
                    e.printStackTrace();
                }
                System.out.println("Il thread " + nome + " riprende l'esecuzione");
                
            }
            //il buffer non è vuoto
            this.pieno = false;         //svuoto il buffer
            System.out.println("Il thread " + nome + " ha tolto dal buffer " + this.n);
            notifyAll();
            return this.n;
        }
    }
}
