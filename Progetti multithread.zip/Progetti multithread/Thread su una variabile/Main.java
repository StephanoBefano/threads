public class Main{
    public static void main(String[] args) throws InterruptedException {
        Contatore cont= new Contatore(0);   //oggetto Contatore

        //devo condividere l'oggetto cont con tutti i thread
        Concorrenza t1= new Concorrenza("t1", cont);
        Concorrenza t2= new Concorrenza("t2", cont);
        Concorrenza t3= new Concorrenza("t3", cont);
        System.out.println("Partenza del processo principale");
        t1.start();
        t2.start();
        t3.start();
        //partono i thread
        
        try {
        t1.join();
        t2.join();
        t3.join();
        } catch (Exception e) {
            e.printStackTrace();
        }
        //aspetto che i thread finiscano
        System.out.println("Valore finale di cont " + cont.cont);
        
        System.out.println("Fine del processo principale");
    }
}