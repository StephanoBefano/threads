public class Concorrenza extends Thread{
    public Contatore cont;      //oggetto condiviso tra i thread
    
    public Concorrenza(String nome, Contatore c){
        super(nome);
        this.cont=c;
    }
    //alternativa è usare un attributo static

    public void run(){
        System.out.println("Partenza del thread "+ getName());
        int n = (int)(Math.random()*10);
        this.cont.incrementa(n, getName());
        //il thread incrementa di un valore casuale cont
        System.out.println("Fine del thread "+ getName());
    }
}
