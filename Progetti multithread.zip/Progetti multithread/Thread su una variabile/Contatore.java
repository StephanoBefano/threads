public class Contatore {
    public int cont;        //dato condiviso

    public Contatore(int cont){
        this.cont = cont;
    }

    //sincronizzo tutto il metodo
    public synchronized void incrementa(int n, String nomeThread){
        this.cont = this.cont + n;
        System.out.println("Il thread " + nomeThread + " incrementa il contatore di "+ n);
    }

    public void decrementa(int n, String nomeThread){
        //creo un blocco di codice sincronizzato
        synchronized (this) {
            this.cont = this.cont - n;
            System.out.println("Il thread " + nomeThread + " decrementa il contatore di "+ n);
        }
        //quando un thread tenta di eseguire la sezione critica deve prima acquisire un lock (su un oggetto)
        //poi esegue la sezione critica e poi rilascia il lock
        //un solo thread alla volta può detenere il lock

        //in java questo meccanismo prende il nome di MONITOR
    }
}
