public class Concorrenza implements Runnable{
    
    private Vettore V;
    private int index;
    

    Concorrenza(Vettore V, int index){
        this.index=index;
        this.V=V;
    }

    @Override
    public void run() {
        System.out.println("Partenza del Thread: " + index);
        try {
            int n = (int)(Math.random()*1000);
            Thread.sleep(n);
        } catch (Exception e) {

        }
        if(index == -1){
            V.StampaVettori();
        } else{
            V.SommaComponente(index);
        }
    }
}

