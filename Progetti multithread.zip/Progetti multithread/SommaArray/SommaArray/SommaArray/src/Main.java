public class Main {
    public static void main(String[] args) throws Exception {


        long start = System.currentTimeMillis();

        final int dim = 3;
        int[] v1 = new int[dim];
        int[] v2 = new int[dim];

        Vettore V = new Vettore(v1, v2);

        Thread[] threads = new Thread[dim];

        for (int i = 0; i < dim; i++) {
            v1[i] = (int)(Math.random()*10);
            v2[i] = (int)(Math.random()*10);

        }
        for (int i = 0; i < threads.length; i++) {
            Concorrenza t = new Concorrenza(V, i);
            threads[i] = new Thread(t);
            threads[i].start();
        }

       
        for (int i = 0; i < threads.length; i++) {
            try{
                threads[i].join();
            }catch(Exception e){
                e.printStackTrace();
            }
        }

        System.out.println("Fine processo");
        Concorrenza th = new Concorrenza(V, -1);
        Thread thr = new Thread(th);
        thr.start();

        long stop = System.currentTimeMillis();
        double tempo = (double)(stop-start)/1000;
        System.out.println("Tempo di esecuzione del processo " + tempo + " secondi");
        
    }
}
