public class Vettore {
    public int[] A = new int[3];
    public int[] B = new int[3];
    public int[] C = new int[3];

    Vettore(int[] A, int[] B){
        this.A = A;
        this.B = B;
    }
    public void SommaComponente(int indice){
        C[indice] = A[indice] + B[indice];
    }
    public void StampaVettori(){
        for (int i = 0; i < A.length; i++) {
            System.out.println("A: " + A[i]);
            System.out.println("B: " + B[i]);
            System.out.println("C: " + C[i]);
        }
    }
}
